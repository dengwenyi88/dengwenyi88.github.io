#!/bin/bash

work=$(pwd)
build=${work}/build
src=${work}/src

rm -rf ${build}
mkdir -p ${build}

source_module=$1
# testbentch_module=${source_module}_tb

cd ${build}
iverilog -I${work}/include -I${src}/include -o "${source_module}.vvp" \
    ${src}/${source_module}_tb.v ${src}/${source_module}.v
vvp -n "${source_module}.vvp"

cd ${work}