#!/bin/bash

work=$(pwd)
build=${work}/build
src=${work}/src

rm -rf ${build}
mkdir -p ${build}

source_module=$1
testbentch_module=${source_module}_tb

cd ${build}
iverilog -o "${testbentch_module}.vvp" ${src}/${testbentch_module}.v ${src}/${source_module}.v
vvp -n "${testbentch_module}.vvp"

cd ${work}