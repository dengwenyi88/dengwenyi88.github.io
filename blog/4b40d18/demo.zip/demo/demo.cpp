
#include <fstream>
#include <iostream>
#include "cmdline.h"
#include "aes.h"

int main(int argc, char *argv[]) {

    cmdline::parser parser;
    parser.add<std::string>("password", 'p', "encrypt key", true, "");
    parser.add<bool>("mode", 'd', "encrypt mode if true", false, true);
    parser.add<std::string>("file", 'f', "encrypt filename", true, "1.pdf");
    parser.parse_check(argc, argv);

    std::string password = parser.get<std::string>("password");
    bool mode = parser.get<bool>("mode");
    std::string filename = parser.get<std::string>("file");
    const int KEY_LEN = 32;
    if (password.length() < KEY_LEN) {
        printf("Your password length Invalid!\n");
        return -1;
    }
	
	uint8_t key[KEY_LEN] = {0};
	strncpy((char*)&key, password.c_str(),KEY_LEN);
    switch (sizeof(key)) {
        default:
        case 16: Nk = 4; Nr = 10; break;
        case 24: Nk = 6; Nr = 12; break;
        case 32: Nk = 8; Nr = 14; break;
	}

    uint8_t* w = (uint8_t*)malloc(Nb*(Nr+1)*4);
    key_expansion(key, w);

    if (mode)  {
        std::ifstream is (filename, std::ifstream::binary);
        std::ofstream os (filename + ".bin", std::ifstream::binary);
        if (is) {
            // get length of file:
            is.seekg (0, is.end);
            int length = is.tellg();
            is.seekg (0, is.beg);
            uint8_t in[16] = {0};
            uint8_t out[16] = {0}; // 128

            while(length > 0) {

                is.read ((char*)in,(length>=16?16:length));
                if (!is) break;
                
                if(length < 16) {
                    int num = 16 - length;
                    for (int i= length;i<16;i++) {
                        in[i] = num;
                    }
                }

                cipher(in /* in */, out /* out */, w /* expanded key */);
                os.write((char*)out, sizeof(out));

                if (length == 16) {
                    for(int i=0;i<16;i++) in[i] = 16;
                    cipher(in,out,w);
                    os.write((char*)out, sizeof(out));
                }

                length = length - is.gcount();
            }

            is.close();
            os.close();
        } else {
            printf("[%s] not exist!\n",filename.c_str());
        }
    }

    if(!mode) {
        std::ifstream is (filename, std::ifstream::binary);
        std::ofstream os (filename + ".bak", std::ifstream::binary);
        if (is) {
            // get length of file:
            is.seekg (0, is.end);
            int length = is.tellg();
            is.seekg (0, is.beg);
            uint8_t in[16] = {0};
            uint8_t out[16] = {0}; // 128

            while(length > 0) {

                is.read ((char*)in,(length>=16?16:length));
                if (!is) break;

                inv_cipher(in /* in */, out /* out */, w /* expanded key */);
                if (length == 16) {
                    int cnt = out[15];
                    if (cnt < 16 ) {
                        os.write((char*)out, sizeof(out) - cnt);
                    }
                } else {
                    os.write((char*)out, sizeof(out));
                }
                
                length = length - is.gcount();
            }

            is.close();
            os.close();
        }else {
            printf("[%s] not exist!\n",filename.c_str());
        }
    }

    free(w);
    return 0;
}