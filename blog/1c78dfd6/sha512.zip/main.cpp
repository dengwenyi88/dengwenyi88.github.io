
#include <fstream>
#include <iostream>
#include <machine/endian.h>
#include "gflags/gflags.h"
#include "sha512.h"

int print_digest(unsigned char *digest, uint32_t len) {
    uint32_t i;
    for (i = 0; i < len; i++)
    {
        printf ("%02x", digest[i]);
    }

    printf("\n");

    return 0;
}

DEFINE_int32(end, 1000, "The last record to read");


int main(int argc, char *argv[]) {

    unsigned char result[HASH_DIGEST_SIZE+1];

    const char * hash_str = "123456";

    SHA512((const unsigned char *)hash_str,(size_t)strlen(hash_str),result);

    print_digest(result,HASH_DIGEST_SIZE);
    // gflags::ParseCommandLineFlags(&argc, &argv, true);

    // std::cout << FLAGS_end << std::endl;
    // double f = 2;
    // f = sqrt2(f);

    // printf("%0x\n",int(f * 1000000));
    return 0;
}