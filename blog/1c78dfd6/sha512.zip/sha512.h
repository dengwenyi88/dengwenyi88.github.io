#ifndef __SHA512_H__
#define __SHA512_H__
#include <cstdint>
#include <string.h>

#define ERR_OK           0
#define ERR_ERR         -1  /* generic error */
#define ERR_INV_PARAM   -2  /* invalid parameter */
#define ERR_TOO_LONG    -3  /* too long */
#define ERR_STATE_ERR   -4  /* state error */

#define SHA512_BLOCK_SIZE           128 /* 1024 bits = 128 bytes */
#define SHA512_LEN_SIZE             16  /*  128 bits =  16 bytes */
#define SHA512_LEN_OFFSET           (SHA512_BLOCK_SIZE - SHA512_LEN_SIZE)
#define SHA512_DIGEST_SIZE          64  /*  512 bits =  64 bytes */

#define SHA512_PADDING_PATTERN      0x80
#define SHA512_ROUND_NUM            80

#define SHA384_DIGEST_SIZE          48  /*  384 bits =  48 bytes */
#define SHA512_224_DIGEST_SIZE      28  /*  224 bits =  28 bytes */
#define SHA512_256_DIGEST_SIZE      32  /*  256 bits =  32 bytes */

#define HASH_BLOCK_SIZE             SHA512_BLOCK_SIZE
#define HASH_LEN_SIZE               SHA512_LEN_SIZE
#define HASH_LEN_OFFSET             SHA512_LEN_OFFSET

#define HASH_DIGEST_SIZE            SHA512_DIGEST_SIZE

#define HASH_PADDING_PATTERN        SHA512_PADDING_PATTERN
#define HASH_ROUND_NUM              SHA512_ROUND_NUM

typedef struct {
    uint64_t high; /* high 64 bits */
    uint64_t low;  /*  low 64 bits */
} uint128_t;

typedef struct sha512_context {
    /* message total length in bytes */
    uint128_t total;

    /* intermedia hash value for each block */
    struct {
        uint64_t a;
        uint64_t b;
        uint64_t c;
        uint64_t d;
        uint64_t e;
        uint64_t f;
        uint64_t g;
        uint64_t h;
    }hash;

    /* last block */
    struct {
        uint32_t used;      /* used bytes */
        uint8_t  buf[128];  /* block data buffer */
    }last;

    uint32_t ext;           /* t value of SHA512/t */
}SHA512_CTX;

unsigned char *SHA512(const unsigned char *d, size_t n, unsigned char *md);
#endif
